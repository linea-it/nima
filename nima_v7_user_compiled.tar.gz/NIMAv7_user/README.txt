888b	888 8888888 888b     d888	 d8888
8888b	888   888   8888b   d8888	d88888
88888b  888   888   88888b.d88888      d88P888
888Y88b 888   888   888Y88888P888     d88P 888
888 Y88b888   888   888 Y888P 888    d88P  888
888  Y88888   888   888  Y8P  888   d88P   888
888   Y8888   888   888   '   888  d8888888888
888    Y888 8888888 888       888 d88P     888

#######    N I M A    T N O    V 7.0   #######	    


Date
----
2018.04.07

New update
----------
-sc_wget.sh: the user can choose MPC to get the data instead of AstDyS. This is only for objects that are not in AstDys and these objects are assumed to have only a designation (ex 2010VX11) and no number. 
-sc_diffjplomc: the user can choose the format for the plot (pdf or png). Note that for pdf, the plots are in two separated (RA and DEC) whereas for png, there are in the same file.
-sc_merge.sh: the script is looking for doublons and make an alert in that case. Note that the script does not do anything and just produce an alert. The user has to manually delete the doublons in the file obs/*.obs

Info:
-----
-sources, data and librairies are now in the NIMAv7_public directory and should remains unchanged
-scripts and results of the script are now in NIMAv7_user directory


Requirements
------------
- gfortran for compilation
- gnuplot for plot
- inkscape for plot conversion


JPL Ephemeris
-------------
JPL DE432 is used in NIMA v7. To avoid big file, the validity for this version is 1850-2050


Installation
------------
In case of first installation, please execute install.sh in the NIMAv7_public directory
After that, each new user has to unzip the NIMAv7_user directory and proceed to installation through install.sh in
NIMAv7_user directory


Scripts
-------
Before orbit determination, you should execute sc_wget first
- sc_wget.sh: download observations from AstDys or MPC and convert into Nima format
- sc_esoopd.sh: Turn offset observations into Nima format
- sc_cat.sh: concatenate all observations of one TNO into one single file
- sc_merge.sh: can chabge the weight of observations and merge observations into one mean observation per night
- sc_fit.sh: Fit the orbit to observation. Can plot the O-C
- sc_importbsp.sh: import JPL ephemeris bsp file. All bsp files must be stored in jplbsp directory
- sc_diffjplomc.sh: Fit the orbit and plot the difference with JPL orbit. Can also plot the O-C
- sc_makebsp.sh: Produce a bsp file from the fitted orbit
- sc_ephem.sh: Compute ephemeris from bsp file or numerical integration


Uninstall
---------
Execute uninstall.sh
					  

Help
----
In case of problems, errors, bugs, etc, please contact J.Desmars josselin.desmars@obspm.fr


