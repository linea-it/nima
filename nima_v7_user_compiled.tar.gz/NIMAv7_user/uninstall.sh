echo "## Uninstallation of NIMA TNO V7 ##"
echo " "
echo " Do you really want to uninstall NIMAV7 and delete unnecessary files (Y if yes)?"
read choice
if [ "$choice" == "Y" ]; then

	echo " I have to be sure... (Y if yes)?"
	read choice2
	if [ "$choice2" == "Y" ]; then
		echo " Delete directories"
		echo "  >obs/"
		rm -r obs/
		echo "  >ci/"
		rm -r ci/
		echo "  >jplbsp/"
		rm -r jplbsp/
		echo "  >lib/"
		rm -r lib/
		echo "  >exe/"
		rm -r exe/
		echo "  >data/"
		rm -r data/
		echo "  >results/"
		rm -r results/
		echo " "
		echo " "
		echo " Uninstallation completed"
	fi
fi	
