read aster
echo "${aster}" | grep -q '[A-Z]'
if [ $? = 0 ]; then
	idspk=-1	    
	if [ "$aster" = "1998WV24" ];  then idspk=3024247 ;fi
	if [ "$aster" = "1998WW31" ];  then idspk=3031823 ;fi
	if [ "$aster" = "1999OJ4" ];   then idspk=3031899 ;fi
	if [ "$aster" = "1999RY214" ]; then idspk=3031911 ;fi
	if [ "$aster" = "1999XY143" ]; then idspk=3031205 ;fi
	if [ "$aster" = "2000QL251" ]; then idspk=3078880 ;fi
	if [ "$aster" = "2000WT169" ]; then idspk=3063121 ;fi
	if [ "$aster" = "2001QC298" ]; then idspk=3092445 ;fi
	if [ "$aster" = "2001QQ322" ]; then idspk=3092452 ;fi
	if [ "$aster" = "2001RZ143" ]; then idspk=3092461 ;fi
	if [ "$aster" = "2001XR254" ]; then idspk=3102795 ;fi
	if [ "$aster" = "2002VF130" ]; then idspk=3143127 ;fi
	if [ "$aster" = "2002VT130" ]; then idspk=3143130 ;fi
	if [ "$aster" = "2002XH91" ];  then idspk=3145524 ;fi
	if [ "$aster" = "2003QA91" ];  then idspk=3160779 ;fi
	if [ "$aster" = "2003QR91" ];  then idspk=3160761 ;fi
	if [ "$aster" = "2003QW111" ]; then idspk=3160800 ;fi
	if [ "$aster" = "2003QY90" ];  then idspk=3160777 ;fi
	if [ "$aster" = "2003TJ58" ];  then idspk=3330211 ;fi
	if [ "$aster" = "2003WU188" ]; then idspk=3172335 ;fi
	if [ "$aster" = "2003UZ413" ]; then idspk=3383250 ;fi
	if [ "$aster" = "2003YU179" ]; then idspk=3330225 ;fi
	if [ "$aster" = "2004PB108" ]; then idspk=3254536 ;fi
	if [ "$aster" = "2004NT33" ];  then idspk=3383255 ;fi
	if [ "$aster" = "2005EF298" ]; then idspk=3277437 ;fi
	if [ "$aster" = "2005EO304" ]; then idspk=3277443 ;fi
	if [ "$aster" = "2005PR21" ];  then idspk=3296542 ;fi
	if [ "$aster" = "2006SF369" ]; then idspk=3354040 ;fi
	if [ "$aster" = "2007TY430" ]; then idspk=3414366 ;fi
	if [ "$aster" = "2005CC79" ];  then idspk=3561995 ;fi
	if [ "$aster" = "2006HH123" ]; then idspk=3335754 ;fi
	if [ "$aster" = "2007JH43" ];  then idspk=3379023 ;fi
	if [ "$aster" = "2008OG19" ];  then idspk=3426644 ;fi
	if [ "$aster" = "2010EK139" ]; then idspk=3515019 ;fi
	if [ "$aster" = "2011FX62" ];  then idspk=3561995 ;fi
	if [ "$aster" = "2005TV189" ]; then idspk=3330235 ;fi
   	if [ "$aster" = "2008SO266" ]; then idspk=3441813 ;fi
   	if [ "$aster" = "2010VX11" ]; then idspk=3573073 ;fi
else
	(( idspk= 2000000 + $aster ))
fi
echo "$idspk" 
