clear
echo ">>>>>>> Compilation of NIMA TNO V7 <<<<<<<<<<"
echo " "
echo "sources directory ?"
read work
echo ">>>>>>> compilation of programs <<<<<<<<<<"
echo " "
cd exe/
echo " >modules"
gfortran -c $work/src/MOD-type.f90
gfortran -c $work/src/MOD-const.f90
echo " >fitobs.f90"
gfortran $work/src/fitobs.f90 -o fitobs.out ../lib/sofa.a
echo " >ephem*.f90"
gfortran $work/src/ephem_bspSSB.f90 -o ephembspSSB.out ../lib/sofa.a ../lib/spice.a
gfortran $work/src/ephem_bsp.f90 -o ephembspSUN.out ../lib/sofa.a ../lib/spice.a
gfortran $work/src/ephem_ni.f90 -o ephemni.out ../lib/sofa.a
gfortran $work/src/diffephem.f90 -o diffephem.out
gfortran $work/src/statoffset.f90 -o stat.out
gfortran $work/src/modat.f90 -o modat.out ../lib/sofa.a
gfortran $work/src/modoffset.f90 -o offset.out ../lib/sofa.a
echo " >sc_makebsp.sh"
gfortran $work/src/compposcheb.f90 -o compposcheb.out ../lib/sofa.a
gfortran $work/src/cheby.f90 -o cheby.out ../lib/sofa.a
gfortran $work/src/makebsp.f90 -o makebsp.out ../lib/spice.a
gfortran $work/src/calpos_ni.f90 -o calposn.out ../lib/sofa.a
gfortran $work/src/calpos_bsp.f90 -o calposb.out ../lib/sofa.a ../lib/spice.a
gfortran $work/src/diff.f90 -o diff.out
echo " >sc_merge.sh"
gfortran $work/src/trackdoublon.f90 -o trackdoublon.out ../lib/sofa.a 
gfortran $work/src/numbernight.f90 -o numbernight.out
gfortran $work/src/weightnight1.f90 -o merge1.out
gfortran $work/src/weightnight2.f90 -o merge2.out
echo " >sc_wget.sh"
gfortran $work/src/transfobs.f90 -o transfobs.out ../lib/sofa.a
gfortran $work/src/transfci.f90 -o transfci.out
gfortran $work/src/transfciMPC.f90 -o transfciMPC.out
gfortran $work/src/transfobsMPC.f90 -o transfobsMPC.out ../lib/sofa.a
gfortran $work/src/compnuit.f90 -o compnuit.out ../lib/sofa.a
echo " "
echo " >>>>compilation done"
echo " "
