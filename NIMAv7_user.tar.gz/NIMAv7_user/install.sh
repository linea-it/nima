clear
echo "888b    888 8888888 888b     d888        d8888 "
echo "8888b   888   888   8888b   d8888       d88888 "
echo "88888b  888   888   88888b.d88888      d88P888 "
echo "888Y88b 888   888   888Y88888P888     d88P 888 "
echo "888 Y88b888   888   888 Y888P 888    d88P  888 "
echo "888  Y88888   888   888  Y8P  888   d88P   888 "
echo "888   Y8888   888   888   '   888  d8888888888 "
echo "888    Y888 8888888 888       888 d88P     888 "
echo " "
echo "#######    N I M A    T N O    V 7.0   #######"
echo " "
echo "                                      APR.2018"
echo " "
echo ">>>>>>> Installation of NIMA TNO V7 <<<<<<<<<<"
echo " "
echo " "
echo " source link (NIMA_public) :"
echo " "
read work
echo " "
echo " NIMA_public directory : $work"
echo " "
echo "  >obs/"
mkdir obs
echo "  >data/"
mkdir data
ln -s $work/data/listobsUAI.dat data/listobsUAI.dat
ln -s $work/data/de.lnx data/de.lnx
ln -s $work/data/bias.dat data/bias.dat
echo "  >ci/"
mkdir ci
echo "  >jplbsp/"
mkdir jplbsp
echo "  >lib/"
mkdir lib
ln -s $work/lib/sofa.a lib/sofa.a
ln -s $work/lib/spice.a lib/spice.a
echo "  >exe/"
mkdir exe
echo "  >results/"
mkdir results
echo " "
echo " "
echo "  >sources compilation?"
echo " press ENTER to continue"
read
echo " "
echo "$work"|./compil.sh
echo " "
echo " "
echo " Installation completed"
